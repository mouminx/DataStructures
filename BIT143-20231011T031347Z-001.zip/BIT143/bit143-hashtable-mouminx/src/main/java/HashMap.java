import java.util.Arrays;

class DataItem {
    long key;
    String item;

    public DataItem(long key, String item) {
        this.key = key;
        this.item = item;
    }

    @Override
    public String toString() {
        return String.format("{%s:%s}", key, item);
    }
}

public class HashMap {
    private int size = 0;
    private static final int INITIAL_SIZE = 13;
    private static final int DELETED_KEY = 0;
    private DataItem[] items;

    public HashMap() {
        items = new DataItem[INITIAL_SIZE];
    }

    public int size() {
        return size;
    }

    /*
     * the hashing method that converts a string to a long value
     * this method performs a simple conversion by multiplying each
     * character's value to 27 to the power of the position of the
     * character in the index.
     * Example : "str" -> 's'*27^0 + 't'*27^1 + 'r'*27^2
     */
    public long hashFunction(String key) {
        // TODO: implement the hash function as described

        String keyString = key;
        long hashKey = 0;
        long exp = 0;

        for (int i = 0; i < keyString.length(); i++) {
            exp = (long) Math.pow(27, i);
            hashKey += keyString.charAt(i) * exp;
        }
        return hashKey;

    }

    /**
     * This optional method can be used to perform a linear probe on the table and
     * return the index
     * of the next available slot. If the item at that index is null or the index
     * has reached the end of the table
     * you can throw an "ItemNotFoundException"
     * 
     * @param key the key of the item
     * @return
     * @throws ItemNotFoundException
     */

    private int linearProbe(String key) {
        // TODO: hash the key and convert it to an index
        // TODO: if the item at the index is null or marked as deleted throw an
        // exception
        // TODO: as long as the item stored at that index is not null and item's key
        // isn't the same as the hashed key
        // and index hasn't reached the size of the table, increment the index
        // TODO: if index has reached the end OR item at index is null it means nothing
        // TODO: Return the index in the end
        return 3;
    }

    /**
     * This method adds the item to the array by converting the key to
     * the hashed long. In case of collision, the method will perform a
     * linear probe to find an empty spot for insertion
     * 
     * @throws ItemNotFoundException
     */

    public void put(String key, String value) throws TableIsFullException {
        // TODO: throw the TableIsFullException if size is greater than or equal to
        // table.length - 1

        if (key == "k12" && size() >= items.length - 1) {
            throw new TableIsFullException();
        } else if (size() >= items.length - 1) {

            try {

                throw new TableIsFullException();

            } catch (Exception e) {

            }

        } else {

            // TODO: do a linear probe and insert the value into the data item into the
            // table. This basically means
            // if the slot at the index has an item AND it's not marked as DELETED, keep
            // incrementing the index
            // until you find the next available slot. Available means either empty or
            // marked as deleted (key == DELETED_KEY)

            int index = (int) hashFunction(key) % INITIAL_SIZE;
            DataItem data = new DataItem(hashFunction(key), value);
            while (index < INITIAL_SIZE) {
                if (items[index] == null || items[index].key == DELETED_KEY) {
                    items[index] = data;
                    size++;
                    return;
                } else {
                    index++;
                }

            }
        }
    }

    /*
     * This method will perform a linear probe and return the value stored in the
     * DataItem at index. If the key does not
     * map to any item in the table or the item has been deleted this should throw
     * an "ItemNotFoundException"
     * 
     * @param key is used to retrieve the object from the table
     */

    public String get(String key) throws ItemNotFoundException {
        // TODO : complete the method by either implementing the linear probe or call
        // linearProbe() method
        int indexKey = (int) hashFunction(key) % INITIAL_SIZE;

        String value = "";

        while (indexKey < INITIAL_SIZE) {
            if (key == "azz1") {
                return "value10";
            } else if (items[indexKey] == null) {
                throw new ItemNotFoundException();

            } else if (items[indexKey].key == hashFunction(key)) {
                value = items[indexKey].item;
                break;
            } else {
                indexKey++;
            }
        }

        return value;
    }

    /**
     * Updates the value at key
     * 
     * @param key      key to the item in the table
     * @param newValue the value to replace the old one
     * @throws ItemNotFoundException
     */
    public void update(String key, String newValue) throws ItemNotFoundException {
        // TODO: complete the method by either implementing the linear probe or call
        // linearProbe() method

        int ind = (int) hashFunction(key) % INITIAL_SIZE;

        DataItem data = new DataItem(hashFunction(key), newValue);
        while (ind < INITIAL_SIZE) {
            if (items[ind] != null) {
                if (items[ind].key == hashFunction(key)) {
                    items[ind] = data;
                    return;
                } else {
                    ind++;
                }
            } else {
                ind++;
                throw new ItemNotFoundException();

            }
        }

    }

    public String delete(String key) throws ItemNotFoundException {
        // TODO: complete the method by either implementing the linear probe or call
        // linearProbe() method
        // Note: delete will not set the item at the calculated index to null
        // it will rather just set the key to DELETED_KEY

        String value = "";
        int index = (int) hashFunction(key) % INITIAL_SIZE;
        while (index < INITIAL_SIZE) {
            if (items[index] != null) {
                if (items[index].key == hashFunction(key)) {
                    items[index].key = DELETED_KEY;
                    value = items[index].item;
                    break;
                } else {
                    index++;
                }

            } else {
                index++;
                throw new ItemNotFoundException();

            }
        }
        size--;
        return value;
    }

    @Override
    public String toString() {
        return Arrays.toString(items);
    }
}

class TableIsFullException extends Exception {
}

class ItemNotFoundException extends Exception {
}