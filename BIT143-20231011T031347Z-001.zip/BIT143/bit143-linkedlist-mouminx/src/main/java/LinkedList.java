public class LinkedList<T> {
    // Definition of the Node class that LinkedList internally uses
    class Node {
        T item;
        Node next;

        public Node() {
        }

        public Node(T item) {
            this.item = item;
        }
    }

    private Node head;
    private Node tail;
    // to keep track of the size of the array
    private int size = 0;

    public void push(T item) {
        // TODO: complete the push method
        Node node = new Node();
        node.item = item;
        node.next = null;

        if(head == null){
            head = node;
            tail = head;
            size++;
        }else{
            Node n = head;
            while(n.next != null){
                n = n.next;
            }
            n.next = node;
            size++;
        }
        // You need to consider 2 cases. When list is empty and when it's not
        // Don't forget to increment size!
    }

    public T get(int i) throws ListIndexOutOfBoundException {
        rangeCheck(i); // this throws an exception but we won't catch it here
        // TODO: complete the rest of the method
        // instead of null, you should return the item stored in the node
        rangeCheck(i);

        Node n = head;
        for(int j = 0; j < i; j++){
            n = n.next;
        }
        return n.item;
    }

    public int find(T item) {
        // TODO: complete the find method
        Node node = new Node(item);
        int index = 0;

        if(head == null){
            return -1;
        }
        if(head.item == item){
            return 0;
        }else{
            Node n = head;
            while(n.next != null){
                index++;
                n = n.next;
                if(n.item.equals(item)){
                    return index;
                }
            }
        }
        return -1;
    }

    public void insert(int i, T item) throws ListIndexOutOfBoundException {
        // TODO: Complete the insert method
        /* there are 3 cases: 
        1. list is empty (head is null)
        2. inserting at the beginning of the list (i = 0)
        3. inserting anywhere else

        

        the new node will be inserted at the index and push the
        current node to right. e.g.
        [ac1][ac2][ac3]
        insert(1, ac1.5)
        [ac1][ac1.5][ac2][ac3]
        insert(3, ac2.5)
        [ac1][ac1.5][ac2][ac2.5][ac3]
        */

        Node node = new Node(item);
        if(this.size == 0){
            this.push(item);
        }else if(i == 0){
            node.next = head;
            head = node;
            this.size++;
        }else{
            rangeCheck(i);
            Node n = this.head;
            for(int j = 0; j < i-1; j++){
                n = n.next;
            }
            node.next = n.next;
            n.next = node;
            this.size++;
        }
    }

    public int size() {
        return size;
    }

    public T delete(int i) throws ListIndexOutOfBoundException, EmptyListException {
        // TODO: complete the delete method
        // use this to store the item and return it in the end
        /*
        similar to insert, consider 3 cases
        empty list, insert at the beginning, and anywhere else
        don't forget to decrement size

        💡 HINT: you can use cursor.next = cursor.next.next
        */
        T deletedItem = null;
        rangeCheck(i);

        if (size == 0) {
            return deletedItem;
        }

        if (i == 0) {
            deletedItem = this.head.item;
            this.head = this.head.next;
        } else {

            Node prev = this.head;
            for (int j = 0; j < i - 1; j++) {
                prev = prev.next;
            }

            deletedItem = prev.next.item;
            prev.next = prev.next.next;
        }
        size--;
        return deletedItem;
    }

    // Utility methods
    public void rangeCheck(int i) throws ListIndexOutOfBoundException {
        if (i < 0 || i >= size)
            throw new ListIndexOutOfBoundException();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        Node cur = head;
        sb.append("[");
        while (cur != null) {
            if (cur.next == null) {
                sb.append(cur.item.toString());
            } else {
                sb.append(cur.item.toString());
                sb.append(", ");
            }
            cur = cur.next;
        }

        sb.append("]");
        return sb.toString();
    }
}

class ListIndexOutOfBoundException extends Exception {
}

class EmptyListException extends Exception {
}
