# Data Structures & Algorithms - Setup
Simply modify the .java file and replace "Hello, World!" with "Hello, DS and Algo!"
