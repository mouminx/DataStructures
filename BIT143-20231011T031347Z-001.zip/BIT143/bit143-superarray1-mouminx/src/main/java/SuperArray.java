import java.util.Arrays;

public class SuperArray {
    private Account[] accounts;
    private int size = 0;

    public SuperArray(int size) {
        this.accounts = new Account[size];
    }

    // put or update
    public void update(int i, Account account) {
        // TODO: call rangeCheck(i) to ensure the index is in range
        rangeCheck(i);
        
        // TODO: assign the account to the location at i
        accounts[i] = account;
        
    }

    // get item at index (read)
    public Account get(int i) {
        // TODO: rangeCheck(i);
        rangeCheck(i);
        // TODO: return the value stored at i
        return accounts[i];
    }
    // find item (search) 
    // this method will return the index of the first occurrence of the item in the array
    public int find(Account account) {
        //TODO: loop through the array up to this.size and as soon as you find the account return the index (i)
        for(int i = 0; i < this.size; i++){
            if(account.equals(accounts[i])){
                return i;
            }
        }
        // TODO: by the time you get out of the loop you haven't found the item, so return -1
        return -1;
    }

    // TODO: this method will return the size which determines the size of the array
    public int size() {
        return size;
    }

    // insert (unique or not unique?)
    public void add(Account ac) {
        if (size >= accounts.length){
            throw new ListIsFullException();
        }
        
        // TODO: add ac to the accounts array at the last index which is the same as size
        accounts[size] = ac;

        // TODO: increment the size by one
        size++;
    }

    // delete an item (by index or by object?)
    //-- by index
    
    // In the first overload we are going to delete an item at the provided index
    // TODO: write a method that receives an index and "deletes" the item at that index
    // write a public method that returns nothing (void) called delete which receives an index
    public void delete(int i) {
        // TODO: make sure the index is in range by calling rangeCheck(i);
        rangeCheck(i);
        
        // TODO: the idea is to write a loop that starts at the index passed to the method, all the way up to "size - 1"
        //   then it copies the next cell to the current one. This shifts all values in the array 
        // HINT: arr[i] = arr[i + 1]
        for(int j = i; j < size-1; j++){
            System.out.println(accounts[j]);
            accounts[j] = accounts[j+1];
            System.out.println(accounts[j]);
        }

        // Account[] newaccounts = new Account[accounts.length];
        // for(int i = 0; i <= accounts.length; i++){

        // }

        
       
        // TODO: After the loop, set the last cell's value to null and decrement size
        accounts[size-1] = null;
        size--;
         
    }

    //-- by object
    // the idea is to delete the first occurrence of the item in the array
    // you already have the methods that can take care of this. Just use those
    public void delete(Account ac) {
        // TODO: call the find method to find the index then delete the item at that index
        // HINT: you already have all the methods you need. Just call them!!
        delete(find(ac));
    
    }

    // this method will check the range of the index and throw an exception if it's not in range
    private void rangeCheck(int i) {
        if (i < 0 || i >= size)
            throw new ArrayIndexOutOfBoundsException();
    }

    @Override
    public String toString() {
        return Arrays.toString(accounts);
    }
}

class ListIsFullException extends RuntimeException {}
