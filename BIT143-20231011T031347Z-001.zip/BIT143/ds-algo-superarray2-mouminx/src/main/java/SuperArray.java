import java.util.Arrays;

public class SuperArray<T> {
    private Object[] items;
    private int size = 0;
    private static final int INITIAL_SIZE = 3;

    public SuperArray() {

        this.items = new Object[INITIAL_SIZE];
    }

    // put or update
    public void update(int i, T item) {
        rangeCheck(i);
        // TODO
        items[i] = item;
    }

    // get item at index (read)
    public T get(int i) {
        rangeCheck(i);
        // every time we need to return an element in the array, we call elements(int i)
        return element(i);
    }
    // find item (search) 
    // this method will return the index of the first occurrence of the item in the array
    public int find(T item) {
        //TODO: loop through the array up to this.size and as soon as you find the item return the index (i)
        for(int i = 0; i < this.size; i++){
            if(item.equals(items[i])){
                return i;
            }
        }
        
        // TODO: by the time you get out of the loop you haven't found the item, so return -1
        return -1;
    }

    // This method will return the size which determines the size of the array
    public int size() {
        return size;
    }

    // This method returns the capacity (only for testing purposes)
    public int capacity() {
        return items.length;
    }

    // Add items to the array at a specific index
    public void add(int i, T item) {      
        // TODO: the trick here is to start at the last index, copy each element to the right
        //  and go down and finally store item at index i
        rangeCheck(i);
        if(size >= items.length){
            items = copyOf(items, items.length + items.length / 2);
        }

        for(int j = items.length-2; j >= i; j--){
            items[j + 1] = items[j];
        }
        items[i] = item;
        size++;
        }

        // Hint: call copyOf to make a copy of the current array if size >= items.length
    

    public void push(T item) {
        //TODO: implement the push method
        // Hint: call copyOf to make a copy of the current array if size >= items.length
        // In both add and push, you need to check for the size of the array. If the array is at 
        // capacity, you need to copy the array into a bigger one that's 50% bigger, 
        // meaning `newLength = items.length + items.length/2`.
        if(size >= items.length){
            items = copyOf(items, items.length + items.length / 2);
        }
        items[size] = item;
        size++;

        }

    public Object pop() {
        // TODO: implement pop
        if(size == 0){
            return null;
        }
        Object element = items[size-1];
        items[size-1] = null;
        size--;
        return element;
        
        
        
        // return null if empty
    }
    

    // TODO: this method will copy everything from a to a new array of bigger size and return it
    private Object[] copyOf(Object[] a, int newLength) {
        // TODO: newLength determines the length of the new array
        Object newItems[] = new Object[newLength];
        for(int i = 0; i < this.size; i++){
            newItems[i] =  a[i];
        }
        return newItems;
    }

    // delete an item (by index or by object?)
    //-- by index
    
    // In the first overload we are going to delete an item at the provided index
    // TODO: write a method that receives an index and "deletes" the item at that index
    // write a public method that returns nothing (void) called delete which receives an index
    public void delete(int i) {
        // TODO: make sure the index is in range by calling rangeCheck(i);
        rangeCheck(i);
        
        // TODO: the idea is to write a loop that starts at the index passed to the method, all the way up to "size - 1"
        //   then it copies the next cell to the current one. This shifts all values in the array 
        // HINT: arr[i] = arr[i + 1]
        for(int j = i; j < size-1; j++){
            items[j] = items[j + 1];
        }
        
        // set the last cell's value to null
        // TODO: After the loop, set the last cell's value to null and decrement size
        items[size-1] = null;
        size--;
    }

    //-- by object
    // the idea is to delete the first occurrence of the item in the array
    // you already have the methods that can take care of this. Just use those
    public void delete(T item) {
        // TODO: call the find method to find the index then delete the item at that index
        // HINT: you already have all the methods you need. Just call them!!
        delete(find(item));
    }

    // this method will check the range of the index and throw an exception if it's not in range
    private void rangeCheck(int i) {
        if (i < 0 || i >= size)
            throw new ArrayIndexOutOfBoundsException();
    }

    @Override
    public String toString() {
        return Arrays.toString(items);
    }

    // This method is used to return an element in the array as T
    @SuppressWarnings("unchecked")
    private T element(int i) {
        return (T) items[i];
    }
}
