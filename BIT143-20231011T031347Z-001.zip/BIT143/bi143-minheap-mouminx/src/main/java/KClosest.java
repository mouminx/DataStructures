import java.util.*;
public class KClosest {

    public static List<Point> find(List<Point> points, Point p, int k) {
        MinHeap<Point> mh = new MinHeap<>();
        List<Point> location =  new ArrayList<>(k);
        for (Point x1: points) {
            double y1 = distance(x1, p);
            mh.offer(x1, y1);
        }
        for (int i=0;i<k;i++) {
            location.add(mh.poll());
        }
        return location;
    }

    private static double distance(Point p1, Point p2) {

        double x = p2.x - p1.x;
        double y = p2.y - p1.y;
        return Math.sqrt((x*x) + (y*y));
    }
}
