import java.util.*;

public class MinHeap<T> {

   private List<Double> doubleList;
   private List<T> value;
   private Map<T, Integer> mapInt;

   public MinHeap() {
       mapInt = new HashMap<>();
       value = new ArrayList<>();
       doubleList = new ArrayList<>();
   }

   public void offer(T obj, double priority) {

       value.add(obj);
       doubleList.add(priority);
       mapInt.put(obj, value.size() - 1);
       valueUp(value.size() - 1);

   }

   private void valueUp(int number) {
    while (number > 0) {
        int u = (number - 1) / 2;
        if (doubleList.get(number) >= doubleList.get(u)) return;
        
        switchValue(u, number);
        number = u;
    }
}

   // Reads the value stored on the top of the heap but doesn't remove it
   public T peek() {

       if (value.isEmpty()) {
        return null;
       }
       return value.get(0);

   }

    // Removes an object from the top of the heap and returns it
    public T poll() {

        if (value.isEmpty()) {
            return null;
        }    

        T q = value.get(0);
        value.set(0, value.get(value.size() - 1));
        doubleList.set(0, doubleList.get(doubleList.size() - 1));
        valueDown(0);
        value.remove(value.size() - 1);
        doubleList.remove(value.size());
        mapInt.remove(q);
        return q;
    }

    private void valueDown(int number) {
        while (number * 2 + 1 < value.size()) {
            int z = number * 2 + 1;
            if (z + 1 < value.size() && doubleList.get(z + 1) < doubleList.get(z)) {
                z++;
            }
 
            if (doubleList.get(number) <= doubleList.get(z)) {
                return;
            }
            switchValue(number, z);
            number = z;
        }
    }

    private void switchValue(int i, int j) {
        T a = value.get(i);
        T b = value.get(j);
        value.set(i, b);
        value.set(j, a);
        double t = doubleList.get(i);
        doubleList.set(i, doubleList.get(j));
        doubleList.set(j, t);
        mapInt.put(a, j);
        mapInt.put(b, i);
    }
 
    // returns true if the object is in the heap, false otherwise
    // What is the time complexity of this operation?
   public boolean contains(T obj) {
       return mapInt.containsKey(obj);
   }

   public int size() {
       return value.size();
   }
}

 