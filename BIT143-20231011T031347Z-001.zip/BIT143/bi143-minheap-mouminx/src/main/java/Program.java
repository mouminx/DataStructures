public class Program {
    public static void main(String[] args) {
        MinHeap<Point> mh = new MinHeap<>();

        mh.offer(new Point(10, 11), 1);
    }
}